SELECT * FROM empleados;
